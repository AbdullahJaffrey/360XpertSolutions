-- SHOW DATABASES;

use sakila;

-- SHOW TABLES;

SELECT 
    *
FROM
    sakila.actor
LIMIT 10;

-- CREATE DATABASE my_test_db;

-- CREATE USER 'test_user'@'localhost' IDENTIFIED BY 'okay(@123!)';

-- GRANT ALL PRIVILEGES ON my_test_db.* TO 'test_user'@'localhost';

-- FLUSH PRIVILEGES;

-- SHOW DATABASES;

-- SHOW GRANTS FOR 'test_user'@'localhost';


-- demo_dbt:
--   outputs:
--     dev_mysql:
--       type: mysql
--       server: localhost
--       port: 3306
--       schema: sakila
--       database: actor
--       username: root
--       password: towbooy97
--       driver: MySQL ODBC 8.0 ANSI Driver
--       ssl_disabled: True
--       threads: 4  # Number of threads for MySQL

--     prod_mysql:
--       type: mysql
--       server: localhost
--       port: 3306
--       schema: sakila
--       database: actor
--       username: root
--       password: towbooy97
--       driver: MySQL ODBC 8.0 ANSI Driver
--       ssl_disabled: True
--       threads: 4  # Number of threads for MySQL

--     dev_postgres:
--       type: postgres
--       host: localhost
--       user: postgres
--       password: towbooy97
--       port: 5432
--       dbname: sales
--       schema: public
--       threads: 4  # Number of threads for PostgreSQL

--   target: dev_mysql  # Default connection

