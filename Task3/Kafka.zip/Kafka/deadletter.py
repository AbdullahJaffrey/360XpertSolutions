import time
import random

# Function to process the message
def process_message(message):
    # Simulating random failures in message processing
    if random.choice([True, False]):
        raise Exception("Failed to process message")
    print(f"Message processed successfully: {message}")

# Function to send the message to DLQ
def send_to_dlq(message):
    # Here, you can write the logic to send to another Kafka topic or save it somewhere (e.g., a file)
    print(f"Message sent to DLQ: {message}")

# Function to handle message processing with retries
def handle_message_with_dlq(message, retries):
    try:
        # Process the message
        process_message(message)
    except Exception as e:
        # If an exception occurs, retry or send to DLQ
        if retries > 0:
            print(f"Retrying... attempts left: {retries}")
            # Wait for some time before retrying (to simulate backoff)
            time.sleep(2)
            handle_message_with_dlq(message, retries-1)
        else:
            # If retries are exhausted, send the message to DLQ
            send_to_dlq(message)

# Example usage: Simulating message consumption
if __name__ == "__main__":
    message = {'data': 'Test message from Kafka'}
    retries = 3  # Number of retry attempts before sending to DLQ
    handle_message_with_dlq(message, retries)
