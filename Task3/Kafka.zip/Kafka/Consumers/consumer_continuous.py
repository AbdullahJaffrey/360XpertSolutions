from kafka import KafkaConsumer
import json

def receive_continuous_messages(topic):
    consumer = KafkaConsumer(
        topic,
        bootstrap_servers='localhost:9092',
        auto_offset_reset='earliest',  # Ensure this is set to receive all messages
        group_id='your_group_id',
        value_deserializer=lambda x: json.loads(x.decode('utf-8'))  # Use value_deserializer instead
    )

    print(f"Listening for messages on topic: {topic}")
    for message in consumer:
        print(f"Received message: {message.value}")

if __name__ == "__main__":
    receive_continuous_messages("fanout_topic")  # Use the actual topic name
