from kafka import KafkaConsumer


consumer = KafkaConsumer(
    'load_balanced_topic',
    bootstrap_servers=['localhost:29092'],
    group_id='load_balancer',
    enable_auto_commit=True
)
