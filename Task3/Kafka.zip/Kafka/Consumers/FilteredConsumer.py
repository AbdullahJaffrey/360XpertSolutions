from kafka import KafkaConsumer
import json

def receive_filtered_messages(topic, filter_key, filter_value):
    consumer = KafkaConsumer(
        topic,
        bootstrap_servers=['localhost:29092'],
        auto_offset_reset='earliest',
        enable_auto_commit=True,
        group_id='filter_group',
        value_serializer=lambda x: json.loads(x.decode('utf-8'))
    )
    
    for message in consumer:
        if message.value.get(filter_key) == filter_value:
            print(f"Received filtered message: {message.value}")
