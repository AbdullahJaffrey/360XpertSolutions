# # # # from kafka import KafkaConsumer
# # # # import json

# # # # def receive_messages(topic, max_messages=10):
# # # #     consumer = KafkaConsumer(
# # # #         topic,
# # # #         bootstrap_servers=['localhost:29092'],
# # # #         auto_offset_reset='earliest',
# # # #         group_id='auto_stop_group',
# # # #         value_deserializer=lambda x: json.loads(x.decode('utf-8'))
# # # #     )
    
# # # #     count = 0
# # # #     print(f"Consumer started for topic '{topic}'. Expecting {max_messages} messages...")
# # # #     for message in consumer:
# # # #         print(f"Received message: {message.value}")
# # # #         count += 1
# # # #         if count >= max_messages:
# # # #             break  # Stop after consuming max_messages

# # # #     consumer.close()  # Close the consumer

# # # # if __name__ == "__main__":
# # # #     receive_messages("your_topic_name_here", max_messages=5)



# # # from kafka import KafkaConsumer
# # # import json

# # # def receive_messages(topic="test"):  # Ensure topic name is correct
# # #     consumer = KafkaConsumer(
# # #         topic,
# # #         bootstrap_servers='localhost:29092',  # Adjust if your Docker container is using a different port
# # #         auto_offset_reset='earliest',
# # #         group_id='broadcast_group',  # Unique group ID for each consumer
# # #         value_deserializer=lambda x: json.loads(x.decode('utf-8'))
# # #     )

# # #     print(f"Listening for messages on topic: {topic}")
    
# # #     # Listening for messages
# # #     for message in consumer:
# # #         print(f"Received message: {message.value}")  # Log the received message

# # # if __name__ == "__main__":
# # #     receive_messages()  # Automatically listens to the default topic

# # from kafka import KafkaConsumer
# # import json

# # def consume_messages(topic="test"):
# #     consumer = KafkaConsumer(
# #         topic,
# #         bootstrap_servers='localhost:9092',
# #         auto_offset_reset='earliest',  # Start reading at the earliest message
# #         group_id='new_group',  # Unique group ID for this consumer
# #         value_deserializer=lambda x: json.loads(x.decode('utf-8'))  # Deserialize JSON messages
# #     )

# #     print(f"Listening for messages on topic: {topic}")

# #     try:
# #         for message in consumer:
# #             print(f"Received message: {message.value}")  # Print received message
# #     except KeyboardInterrupt:
# #         print("Stopping the consumer...")
# #     finally:
# #         consumer.close()  # Ensure the consumer is closed properly

# # if __name__ == "__main__":
# #     consume_messages()  # Call the function to start consuming

# from kafka import KafkaConsumer
# import json

# def receive_notifications():
#     consumer = KafkaConsumer(
#         'test',  # Ensure topic name matches producer
#         bootstrap_servers=['localhost:29092'],  # Change if necessary
#         auto_offset_reset='earliest',
#         enable_auto_commit=True,
#         group_id='notification_group',
#         value_deserializer=lambda x: json.loads(x.decode('utf-8'))
#     )
    
#     print("Listening for messages on topic: test")  # Added log statement

#     for message in consumer:
#         print(f"Received message: {message.value}")

# if __name__ == "__main__":
#     receive_notifications()

from kafka import KafkaConsumer
import json
import time

def receive_notifications():
    consumer = KafkaConsumer(
        'test',  # Ensure topic name matches producer
        bootstrap_servers=['localhost:29092'],  # Change if necessary
        auto_offset_reset='earliest',
        enable_auto_commit=True,
        group_id='notification_group',
        value_deserializer=lambda x: json.loads(x.decode('utf-8'))
    )
    
    print("Listening for messages on topic: test ")

    while True:
        try:
            message = consumer.poll(timeout_ms=1000)  # Poll for messages with a timeout
            for tp, messages in message.items():
                for msg in messages:
                    print(f"Received message: {msg.value}")
        except KeyboardInterrupt:
            print("Consumer stopped.")
            break

if __name__ == "__main__":
    receive_notifications()
