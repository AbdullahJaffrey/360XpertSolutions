from kafka import KafkaConsumer

consumer = KafkaConsumer(
    'ack_topic',
    bootstrap_servers=['localhost:9092'],
    auto_offset_reset='earliest',
    enable_auto_commit=False,  # Disabling auto-commit for manual control
    group_id='ack_group'
)

for message in consumer:
    # Process message
    print(f"Processed message: {message.value}")
    
    # Manually commit offset
    consumer.commit()
