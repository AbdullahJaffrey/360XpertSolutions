from kafka import KafkaConsumer
import json

def receive_topic_based_message(topic):
    consumer = KafkaConsumer(
        topic,
        bootstrap_servers=['localhost:29092'],
        auto_offset_reset='earliest',
        enable_auto_commit=True,
        group_id='topic_group',
        value_serializer=lambda x: json.loads(x.decode('utf-8'))
    )
    
    for message in consumer:
        print(f"Received message from topic '{topic}': {message.value}")
