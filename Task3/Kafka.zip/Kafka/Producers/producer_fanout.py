from kafka import KafkaProducer
import json

def send_notification(message):
    # Kafka producer setup
    producer = KafkaProducer(
        bootstrap_servers=['localhost:29092'],  # Change to your broker's address
        value_serializer=lambda v: json.dumps(v).encode('utf-8')
    )
    topic = 'test-topic'  # Change to the topic you want to send the message to
    producer.send(topic, {'message': message})  # Change the message format if needed
    producer.flush()  # Ensure the message is sent before proceeding
    producer.close()
    print(f"Message sent to topic '{topic}': {message}")

if __name__ == "__main__":
    send_notification("This is a test message!")
