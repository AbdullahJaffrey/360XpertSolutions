
from kafka import KafkaProducer
import json

def send_topic_based_message(topic, message):
    producer = KafkaProducer(
        bootstrap_servers=['localhost:29092'],
        value_serializer=lambda v: json.dumps(v).encode('utf-8')
    )
    producer.send(topic, {'message': message})
    producer.flush()
    producer.close()
    print(f"Message sent to topic '{topic}': {message}")
